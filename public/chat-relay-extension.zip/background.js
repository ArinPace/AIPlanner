const plannerOrigin='https://aiplanner-ten.vercel.app'
const validChat=url=>{try{return new URL(url).origin==='https://chatgpt.com'}catch{return false}}
const chatLocation=url=>{const u=new URL(url);return u.origin+u.pathname}
async function pageStatus(tab){
 try{return await chrome.tabs.sendMessage(tab.id,{type:'planner-relay-status'})}
 catch{
  // Existing tabs may predate installation. Inject only into the selected ChatGPT tab.
  await chrome.scripting.executeScript({target:{tabId:tab.id},files:['chatgpt.js']})
  return chrome.tabs.sendMessage(tab.id,{type:'planner-relay-status'})
 }
}
async function target(plannerTab){
 const key='chatTab:'+plannerTab,urlKey='chatUrl:'+plannerTab,entry=await chrome.storage.session.get([key,urlKey]),id=entry[key]
 if(typeof id!=='number')return null
 try{const tab=await chrome.tabs.get(id);return validChat(tab.url)&&(!entry[urlKey]||entry[urlKey]===chatLocation(tab.url))?tab:null}catch{return null}
}
chrome.runtime.onConnect.addListener(port=>{
 if(port.name!=='planner-chat-relay'||!port.sender?.tab||new URL(port.sender.url).origin!==plannerOrigin){port.disconnect();return}
 const plannerTab=port.sender.tab.id
 const reply=value=>{try{port.postMessage(value)}catch{/* Planner was closed; never resend the request. */}}
 port.onMessage.addListener(async message=>{
  try{
   if(message.type==='new-chat'){
    let tab=await target(plannerTab)
    if(!tab){tab=await chrome.tabs.create({url:'https://chatgpt.com/',active:true});await chrome.storage.session.set({['chatTab:'+plannerTab]:tab.id});await chrome.storage.session.remove('chatUrl:'+plannerTab)}
    for(let attempt=0;attempt<30;attempt++){
     try{await pageStatus(await chrome.tabs.get(tab.id));break}catch(error){if(attempt===29)throw error;await new Promise(resolve=>setTimeout(resolve,300))}
    }
    const result=await chrome.tabs.sendMessage(tab.id,{type:'planner-relay-new-chat'})
    if(result.error)throw Error(result.error)
    tab=await chrome.tabs.get(tab.id)
    await chrome.storage.session.set({['chatUrl:'+plannerTab]:chatLocation(tab.url)})
    await chrome.storage.session.remove('outcome:'+plannerTab)
    reply({type:'ready',installed:true,...result,reason:'New chat ready in Ai Planner.'});return
   }
   if(message.type==='list-tabs'){
    const tabs=await chrome.tabs.query({url:'https://chatgpt.com/*'})
    reply({type:'tabs',tabs:tabs.filter(tab=>validChat(tab.url)).map(tab=>({id:tab.id,title:tab.title||'ChatGPT',url:chatLocation(tab.url)}))});return
   }
   if(message.type==='select-tab'){
    if(!Number.isInteger(message.tabId))throw Error('Choose a ChatGPT tab.')
    const selected=await chrome.tabs.get(message.tabId)
    if(!validChat(selected.url))throw Error('Only a ChatGPT tab can be connected.')
    const bound=new URL(selected.url).pathname==='/'?null:chatLocation(selected.url)
    await chrome.storage.session.set({['chatTab:'+plannerTab]:selected.id})
    if(bound)await chrome.storage.session.set({['chatUrl:'+plannerTab]:bound})
    else await chrome.storage.session.remove('chatUrl:'+plannerTab)
    await chrome.storage.session.remove('outcome:'+plannerTab)
    const status=await pageStatus(selected)
    if(/\/(?:g\/[^/]+\/)?c\//.test(new URL(selected.url).pathname)){
     const moved=await chrome.tabs.sendMessage(selected.id,{type:'planner-relay-move-chat'})
     if(moved.error)throw Error(moved.error)
     const updated=await chrome.tabs.get(selected.id)
     await chrome.storage.session.set({['chatUrl:'+plannerTab]:chatLocation(updated.url)})
    }
    reply({type:'ready',installed:true,connected:status.connected===true,selectedTitle:selected.title||'ChatGPT',reason:status.connected?'Existing ChatGPT Work tab connected in Ai Planner.':'Selected tab is linked. Sign in and select Work there, then check again.'});return
   }
   if(message.type==='connect'){
    let tab=await target(plannerTab)
    if(!tab){tab=await chrome.tabs.create({url:'https://chatgpt.com/',active:true});await chrome.storage.session.set({['chatTab:'+plannerTab]:tab.id});await chrome.storage.session.remove('chatUrl:'+plannerTab)}
    else await chrome.tabs.update(tab.id,{active:true})
    reply({type:'ready',installed:true,connected:false,reason:'A separate ChatGPT tab is open. Sign in and select Work there, then return to Planner.'});return
   }
   let tab=await target(plannerTab)
   if(message.type==='send'){
    if(!tab)throw Error('Connect a ChatGPT tab first.')
    const bound=(await chrome.storage.session.get('chatUrl:'+plannerTab))['chatUrl:'+plannerTab]
   if(!bound&&new URL(tab.url).pathname!=='/')throw Error('Choose Use existing tab to explicitly connect this conversation before sending.')
    if(typeof message.id!=='string'||typeof message.message!=='string'||message.message.length>12000)throw Error('Invalid message.')
    await pageStatus(tab)
    if(!/^\/g\/g-p-[^/]+\/(?:project|c\/)/.test(new URL(tab.url).pathname)){
     const preparation=await chrome.tabs.sendMessage(tab.id,{type:/\/c\//.test(new URL(tab.url).pathname)?'planner-relay-move-chat':'planner-relay-new-chat'})
     if(preparation.error)throw Error(preparation.error)
     tab=await chrome.tabs.get(tab.id)
     await chrome.storage.session.set({['chatUrl:'+plannerTab]:chatLocation(tab.url)})
    }
    const sentKey='sent:'+plannerTab+':'+message.id
    if((await chrome.storage.session.get(sentKey))[sentKey])throw Error('This message may already have been sent. Check ChatGPT before resending.')
    await chrome.storage.session.set({[sentKey]:true})
    await chrome.tabs.sendMessage(tab.id,{type:'planner-relay-send',id:message.id,message:message.message})
    return
   }
   if(['hello','status'].includes(message.type)){
    let status={connected:false}
    if(tab)status=await pageStatus(tab).catch(()=>({connected:false,reason:'The selected ChatGPT tab needs to be reloaded. Reload it, select Work and check again.'}))
    else status.reason='Extension detected. Choose Use existing tab, or Connect ChatGPT tab to open a new one.'
    reply({type:'ready',installed:true,extensionVersion:chrome.runtime.getManifest().version,...status})
    const saved=(await chrome.storage.session.get('outcome:'+plannerTab))['outcome:'+plannerTab]
    if(saved)reply(saved)
   }
  }catch(error){reply({type:'error',id:message.id,error:String(error.message||'Browser relay unavailable.')})}
 })
 const listener=(message,sender)=>{
  if(!['planner-relay-progress','planner-relay-finish'].includes(message?.type)||!validChat(sender.url))return
  void chrome.storage.session.get('chatTab:'+plannerTab).then(async entry=>{
   if(sender.tab?.id!==entry['chatTab:'+plannerTab])return
   const tab=await chrome.tabs.get(sender.tab.id)
   if(/^\/(?:g\/[^/]+\/)?c\/[a-z0-9-]+$/i.test(new URL(tab.url).pathname))void chrome.storage.session.set({['chatUrl:'+plannerTab]:chatLocation(tab.url)})
   const output={type:message.type==='planner-relay-finish'?'finish':'progress',id:message.id,reply:message.reply,error:message.error}
   if(output.type==='finish')void chrome.storage.session.set({['outcome:'+plannerTab]:output})
   reply(output)
  })
 }
 chrome.runtime.onMessage.addListener(listener)
 port.onDisconnect.addListener(()=>chrome.runtime.onMessage.removeListener(listener))
})
